public class JsonDataReader {

    String userName, passwrpasswrod ;

    public void jasonReader(){

    }


        }